/* Sample UDP server */
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>

//get the system time
void curtime(char* tms){
       time_t ct;
       char* cts;
       ct=time(NULL);
       cts=ctime(&ct);
       int i=0,j=0;
    
       for(i=11;i<=18;i++,j++){
       	tms[j]=cts[i];
       }
}
//to get wait for one second
void delay(int mls)
{
    long pause;
    clock_t now,next;

    pause = mls*(CLOCKS_PER_SEC/1000);
    now = next = clock();
    while( (now-next) < pause )
        now = clock();
}



int main(int argc, char**argv){
	int sockfd,n,i;
	struct sockaddr_in servaddr, cliaddr;
	socklen_t len;
	char mesg[1000], banner[1000];	
	int num =0,stor;
	
	sockfd=socket(AF_INET,SOCK_DGRAM,0);	//create a socket
	servaddr.sin_family = AF_INET;	//address family
	servaddr.sin_addr.s_addr=htonl(INADDR_ANY);	//IP address in the network byte order
	servaddr.sin_port=htons(32000);		
	bind(sockfd,(struct sockaddr *)&servaddr,sizeof(servaddr));
	len = sizeof(cliaddr);
	n=recvfrom(sockfd,mesg,1000,0,(struct sockaddr*)&cliaddr,&len);
		
	while(1){
		curtime(mesg); //get time
		sendto(sockfd,mesg,n,0,(struct sockaddr*)&cliaddr,sizeof(cliaddr)); //time send to the client 
		mesg[n] = 0;
		printf("Sent time to client: %s",mesg);
       		delay(1000); //wait for second	
	}
	
return 0;
}
