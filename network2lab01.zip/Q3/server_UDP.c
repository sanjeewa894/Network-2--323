/* Sample UDP server */
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>


int main(int argc, char**argv){
	int sockfd,n,i;
	struct sockaddr_in servaddr, cliaddr;
	socklen_t len;
	char mesg[1000], banner[1000];	
	int num =0,stor;

	sockfd=socket(AF_INET,SOCK_DGRAM,0);	//create a socket
	servaddr.sin_family = AF_INET;	//address family
	servaddr.sin_addr.s_addr=htonl(INADDR_ANY);	//IP address in the network byte order
	servaddr.sin_port=htons(32000);		
	
	while(1){
		
		bind(sockfd,(struct sockaddr *)&servaddr,sizeof(servaddr));
		len = sizeof(cliaddr);
		n=recvfrom(sockfd,mesg,1000,0,(struct sockaddr*)&cliaddr,&len);
		//initialize the number of sentences that going to send
			if(num ==0){
				stor = atoi(mesg);
				sendto(sockfd,mesg,n,0,(struct sockaddr*)&cliaddr,sizeof(cliaddr)); //send msg to client
			}
			else{
				int x; ///here goes upper case converting 
				for ( x = 0; x <= strlen(mesg); x++ )
				banner[x] = toupper(mesg[x]);
				 // end convertL
				sendto(sockfd,banner,n,0,(struct sockaddr*)&cliaddr,sizeof(cliaddr)); //send msg to client
			}
		
		mesg[n] = 0;		
		printf("Received: %s\n",mesg);
		
		if(num == stor) break; //TO BREAK loop when reach to limit
		num++;;		
	}
	
return 0;
}
